from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class IssueCreate(BaseModel):
    title: str
    description: Optional[str] = None
    error_message: Optional[str] = None
    code_snippet: Optional[str] = None
    priority: Optional[str] = "medium"
    error_type: Optional[str] = None
    raised_by: Optional[int] = None
    assigned_to: Optional[int] = None

class IssueUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    assigned_to: Optional[int] = None

class IssueResponse(BaseModel):
    id: int
    title: str
    description: Optional[str]
    error_message: Optional[str]
    code_snippet: Optional[str]
    priority: str
    error_type: Optional[str]
    status: str
    raised_by: Optional[int]
    assigned_to: Optional[int]
    created_at: Optional[datetime]

    class Config:
        from_attributes = True