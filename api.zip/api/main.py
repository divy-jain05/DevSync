from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from api.routes import issues, users, auth, frontend, websocket

app = FastAPI(
    title="DevSync API",
    description="Collaborative Developer Issue Tracker API",
    version="1.0.0"
)

app.mount("/static", StaticFiles(directory="static"), name="static")

app.include_router(frontend.router)
app.include_router(auth.router)
app.include_router(issues.router)
app.include_router(users.router)
app.include_router(websocket.router)

@app.get("/api")
def root():
    return {"message": "Welcome to DevSync API!"}