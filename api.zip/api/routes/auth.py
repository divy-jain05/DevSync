from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User
from api.auth import hash_password, verify_password, create_access_token
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/auth", tags=["Authentication"])

class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str
    role: Optional[str] = "developer"

class LoginRequest(BaseModel):
    email: str
    password: str

# Register
@router.post("/register")
def register(request: RegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == request.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered!")
    
    hashed = hash_password(request.password)
    user = User(
        name=request.name,
        email=request.email,
        password=hashed,
        role=request.role
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"message": f"User {user.name} registered successfully!"}

# Login
@router.post("/login")
def login(request: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == request.email).first()
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found!")
    
    if not verify_password(request.password, user.password):
        raise HTTPException(status_code=401, detail="Wrong password!")
    
    token = create_access_token({"sub": user.email, "role": user.role})
    
    return {
        "access_token": token,
        "token_type": "bearer",
        "user_name": user.name,
        "role": user.role
    }