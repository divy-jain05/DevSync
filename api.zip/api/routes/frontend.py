from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Issue, User, Comment, CommentReaction
from api.auth import verify_password

router = APIRouter(tags=["Frontend"])
templates = Jinja2Templates(directory="templates")

# ── HOME ──────────────────────────────────────
@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return RedirectResponse(url="/login")

# ── LOGIN ─────────────────────────────────────
@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse(
        request, "login.html",
        {"session_user": None, "error": None}
    )

@router.post("/login")
def login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.email == email).first()
    if not user or not user.password:
        return templates.TemplateResponse(
            request, "login.html",
            {"session_user": None, "error": "User not found!"}
        )
    if not verify_password(password, user.password):
        return templates.TemplateResponse(
            request, "login.html",
            {"session_user": None, "error": "Wrong password!"}
        )
    response = RedirectResponse(url="/dashboard", status_code=302)
    response.set_cookie("user_name", user.name)
    response.set_cookie("user_id", str(user.id))
    return response

# ── LOGOUT ────────────────────────────────────
@router.get("/logout")
def logout():
    response = RedirectResponse(url="/login")
    response.delete_cookie("user_name")
    response.delete_cookie("user_id")
    return response

# ── DASHBOARD ─────────────────────────────────
@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db)):
    user_name = request.cookies.get("user_name")
    if not user_name:
        return RedirectResponse(url="/login")

    total          = db.query(Issue).count()
    open_count     = db.query(Issue).filter(Issue.status == "open").count()
    inprog_count   = db.query(Issue).filter(Issue.status == "in-progress").count()
    resolved_count = db.query(Issue).filter(Issue.status == "resolved").count()
    recent_issues  = db.query(Issue).order_by(Issue.created_at.desc()).limit(10).all()

    return templates.TemplateResponse(
        request, "dashboard.html", {
            "session_user": user_name,
            "total": total,
            "open_count": open_count,
            "inprog_count": inprog_count,
            "resolved_count": resolved_count,
            "recent_issues": recent_issues
        }
    )

# ── ALL ISSUES ────────────────────────────────
@router.get("/issues", response_class=HTMLResponse)
def issues_page(request: Request, message: str = None, db: Session = Depends(get_db)):
    user_name = request.cookies.get("user_name")
    if not user_name:
        return RedirectResponse(url="/login")

    issues = db.query(Issue).order_by(Issue.created_at.desc()).all()
    return templates.TemplateResponse(
        request, "issues.html", {
            "session_user": user_name,
            "issues": issues,
            "message": message
        }
    )

# ── CREATE ISSUE ──────────────────────────────
@router.get("/issues/create", response_class=HTMLResponse)
def create_issue_page(request: Request, db: Session = Depends(get_db)):
    user_name = request.cookies.get("user_name")
    user_id   = request.cookies.get("user_id")
    if not user_name:
        return RedirectResponse(url="/login")

    users = db.query(User).all()
    return templates.TemplateResponse(
        request, "create_issue.html", {
            "session_user": user_name,
            "current_user_id": user_id,
            "users": users,
            "error": None
        }
    )

@router.post("/issues/create")
def create_issue_submit(
    request: Request,
    title: str = Form(...),
    description: str = Form(""),
    priority: str = Form("medium"),
    error_type: str = Form(""),
    error_message: str = Form(""),
    code_snippet: str = Form(""),
    assigned_to: str = Form(""),
    raised_by: str = Form(""),
    db: Session = Depends(get_db)
):
    user_name = request.cookies.get("user_name")
    if not user_name:
        return RedirectResponse(url="/login")

    user_id = request.cookies.get("user_id")
    new_issue = Issue(
        title=title,
        description=description,
        priority=priority,
        error_type=error_type,
        error_message=error_message,
        code_snippet=code_snippet,
        assigned_to=int(assigned_to) if assigned_to else None,
        raised_by=int(user_id) if user_id else None
    )
    db.add(new_issue)
    db.commit()
    return RedirectResponse(url="/issues?message=Issue raised successfully!", status_code=302)

# ── ISSUE DETAIL ──────────────────────────────
@router.get("/issues/{issue_id}/detail", response_class=HTMLResponse)
def issue_detail(issue_id: int, request: Request, db: Session = Depends(get_db)):
    user_name = request.cookies.get("user_name")
    user_id   = request.cookies.get("user_id")
    if not user_name:
        return RedirectResponse(url="/login")

    issue    = db.query(Issue).filter(Issue.id == issue_id).first()
    comments = db.query(Comment, User).join(
        User, Comment.user_id == User.id
    ).filter(Comment.issue_id == issue_id).order_by(Comment.created_at.asc()).all()
    users    = db.query(User).all()

    user_likes    = []
    user_dislikes = []
    if user_id:
        reactions     = db.query(CommentReaction).filter(
            CommentReaction.user_id == int(user_id)
        ).all()
        user_likes    = [r.comment_id for r in reactions if r.reaction == 'like']
        user_dislikes = [r.comment_id for r in reactions if r.reaction == 'dislike']

    return templates.TemplateResponse(
        request, "issue_detail.html", {
            "session_user": user_name,
            "issue": issue,
            "comments": comments,
            "users": users,
            "user_likes": user_likes,
            "user_dislikes": user_dislikes
        }
    )

# ── ADD COMMENT ───────────────────────────────
@router.post("/issues/{issue_id}/comment")
def add_comment(
    issue_id: int,
    request: Request,
    comment_text: str = Form(...),
    db: Session = Depends(get_db)
):
    user_id = request.cookies.get("user_id")
    if not user_id:
        return RedirectResponse(url="/login")

    new_comment = Comment(
        issue_id=issue_id,
        user_id=int(user_id),
        comment=comment_text
    )
    db.add(new_comment)
    db.commit()
    return RedirectResponse(url=f"/issues/{issue_id}/detail", status_code=302)

# ── UPDATE STATUS ─────────────────────────────
@router.post("/issues/{issue_id}/status")
def update_status(
    issue_id: int,
    status: str = Form(...),
    db: Session = Depends(get_db)
):
    issue = db.query(Issue).filter(Issue.id == issue_id).first()
    if issue:
        issue.status = status
        db.commit()
    return RedirectResponse(url="/issues", status_code=302)

# ── DELETE ISSUE ──────────────────────────────
@router.get("/issues/{issue_id}/delete")
def delete_issue(issue_id: int, db: Session = Depends(get_db)):
    issue = db.query(Issue).filter(Issue.id == issue_id).first()
    if issue:
        db.delete(issue)
        db.commit()
    return RedirectResponse(url="/issues", status_code=302)

# ── LIKE COMMENT ──────────────────────────────
@router.get("/comments/{comment_id}/like")
def like_comment(comment_id: int, request: Request, db: Session = Depends(get_db)):
    user_id = request.cookies.get("user_id")
    if not user_id:
        return RedirectResponse(url="/login")

    user_id = int(user_id)
    comment = db.query(Comment).filter(Comment.id == comment_id).first()

    existing = db.query(CommentReaction).filter(
        CommentReaction.comment_id == comment_id,
        CommentReaction.user_id == user_id
    ).first()

    if existing:
        if existing.reaction == 'like':
            db.delete(existing)
            comment.likes -= 1
        else:
            existing.reaction = 'like'
            comment.likes += 1
            comment.dislikes -= 1
    else:
        db.add(CommentReaction(comment_id=comment_id, user_id=user_id, reaction='like'))
        comment.likes += 1

    db.commit()
    return RedirectResponse(url=f"/issues/{comment.issue_id}/detail", status_code=302)

# ── DISLIKE COMMENT ───────────────────────────
@router.get("/comments/{comment_id}/dislike")
def dislike_comment(comment_id: int, request: Request, db: Session = Depends(get_db)):
    user_id = request.cookies.get("user_id")
    if not user_id:
        return RedirectResponse(url="/login")

    user_id = int(user_id)
    comment = db.query(Comment).filter(Comment.id == comment_id).first()

    existing = db.query(CommentReaction).filter(
        CommentReaction.comment_id == comment_id,
        CommentReaction.user_id == user_id
    ).first()

    if existing:
        if existing.reaction == 'dislike':
            db.delete(existing)
            comment.dislikes -= 1
        else:
            existing.reaction = 'dislike'
            comment.dislikes += 1
            comment.likes -= 1
    else:
        db.add(CommentReaction(comment_id=comment_id, user_id=user_id, reaction='dislike'))
        comment.dislikes += 1

    db.commit()
    return RedirectResponse(url=f"/issues/{comment.issue_id}/detail", status_code=302)