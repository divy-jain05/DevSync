import streamlit as st
import pandas as pd
from app.db import fetch_all

def show():
    st.title(" Dashboard")
    st.markdown("---")

    
    total    = fetch_all("SELECT COUNT(*) as count FROM issues")[0]['count']
    open_i   = fetch_all("SELECT COUNT(*) as count FROM issues WHERE status='open'")[0]['count']
    inprog   = fetch_all("SELECT COUNT(*) as count FROM issues WHERE status='in-progress'")[0]['count']
    resolved = fetch_all("SELECT COUNT(*) as count FROM issues WHERE status='resolved'")[0]['count']

    col1, col2, col3, col4 = st.columns(4)
    col1.metric(" Total", total)
    col2.metric(" Open", open_i)
    col3.metric(" In Progress", inprog)
    col4.metric(" Resolved", resolved)

    st.markdown("---")

    st.subheader("Issues by Status")
    status_data = fetch_all("SELECT status, COUNT(*) as count FROM issues GROUP BY status")
    if status_data:
        st.bar_chart(pd.DataFrame(status_data).set_index('status'))

    st.subheader("Issues by Team Member")
    member_data = fetch_all("""
        SELECT u.name, COUNT(*) as count FROM issues i
        JOIN users u ON i.assigned_to = u.id GROUP BY u.name
    """)
    if member_data:
        st.bar_chart(pd.DataFrame(member_data).set_index('name'))

    st.markdown("---")

    
    st.subheader("Recent Issues")
    recent = fetch_all("""
        SELECT i.id, i.title, i.priority, i.status,
               u1.name as raised_by, u2.name as assigned_to
        FROM issues i
        LEFT JOIN users u1 ON i.raised_by = u1.id
        LEFT JOIN users u2 ON i.assigned_to = u2.id
        ORDER BY i.created_at DESC LIMIT 10
    """)
    if recent:
        st.dataframe(pd.DataFrame(recent), use_container_width=True)
    else:
        st.info("No issues yet!")