import streamlit as st
from app.db import fetch_all, execute_query

def show():
    st.title(" All Issues")
    st.markdown("---")

    col1, col2 = st.columns(2)
    with col1:
        status_filter = st.selectbox("Filter by Status", ["All", "open", "in-progress", "resolved"])
    with col2:
        users = fetch_all("SELECT id, name FROM users")
        user_map = {u['name']: u['id'] for u in users}
        user_names = ["All"] + [u['name'] for u in users]
        assignee_filter = st.selectbox("Filter by Assignee", user_names)

    query = """
        SELECT i.*, u1.name as raised_by_name, u2.name as assigned_to_name
        FROM issues i
        LEFT JOIN users u1 ON i.raised_by = u1.id
        LEFT JOIN users u2 ON i.assigned_to = u2.id
        WHERE 1=1
    """
    params = []
    if status_filter != "All":
        query += " AND i.status = %s"
        params.append(status_filter)
    if assignee_filter != "All":
        query += " AND u2.name = %s"
        params.append(assignee_filter)
    query += " ORDER BY i.created_at DESC"

    issues = fetch_all(query, params)

    if not issues:
        st.warning("No issues found!")
        return

    st.markdown(f"**Total: {len(issues)} issue(s)**")
    st.markdown("---")

    for issue in issues:
        priority_icon = "🔴" if issue['priority'] == 'high' else "🟡" if issue['priority'] == 'medium' else "🟢"
        status_icon = "🔵" if issue['status'] == 'open' else "🟠" if issue['status'] == 'in-progress' else "✅"

        with st.expander(f"{priority_icon} #{issue['id']} — {issue['title']} | {status_icon} {issue['status'].upper()}"):


            st.markdown(f"**Raised By:** {issue['raised_by_name']} | **Assigned To:** {issue['assigned_to_name'] or 'Unassigned'}")
            st.markdown(f"**Priority:** {issue['priority']} | **Error Type:** {issue['error_type']}")

            if issue['error_message']:
                st.code(issue['error_message'], language="bash")
            if issue['code_snippet']:
                st.code(issue['code_snippet'], language="python")

            st.markdown("---")

           
            col1, col2 = st.columns(2)
            with col1:
                new_status = st.selectbox("Update Status", ["open", "in-progress", "resolved"],
                    index=["open", "in-progress", "resolved"].index(issue['status']),
                    key=f"status_{issue['id']}")
                if st.button("Update", key=f"update_{issue['id']}"):
                    execute_query("UPDATE issues SET status=%s WHERE id=%s", (new_status, issue['id']))
                    execute_query("INSERT INTO activity_log (issue_id, user_id, action) VALUES (%s,%s,%s)",
                        (issue['id'], 1, f"Status changed to {new_status}"))
                    st.success("Updated!")
                    st.rerun()

            
            with col2:
                st.markdown("###")
                if st.button(" Delete", key=f"delete_{issue['id']}"):
                    execute_query("DELETE FROM issues WHERE id=%s", (issue['id'],))
                    st.success("Deleted!")
                    st.rerun()

            st.markdown("---")

           
            st.subheader(" Comments")
            comments = fetch_all("""
                SELECT c.comment, c.created_at, u.name FROM comments c
                JOIN users u ON c.user_id = u.id
                WHERE c.issue_id = %s ORDER BY c.created_at ASC
            """, (issue['id'],))

            for c in comments:
                st.markdown(f">  **{c['name']}** — {c['comment']}")

            comment_text = st.text_area("Add comment", key=f"comment_{issue['id']}", placeholder="Write solution here...")
            comment_user = st.selectbox("Comment as", [u['name'] for u in users], key=f"cuser_{issue['id']}")

            if st.button("Add Comment", key=f"addcomment_{issue['id']}"):
                if comment_text.strip():
                    execute_query("INSERT INTO comments (issue_id, user_id, comment) VALUES (%s,%s,%s)",
                        (issue['id'], user_map[comment_user], comment_text))
                    st.success("Comment added!")
                    st.rerun()

           
           
            st.subheader(" Activity Log")
            activities = fetch_all("""
                SELECT a.action, a.created_at, u.name FROM activity_log a
                JOIN users u ON a.user_id = u.id
                WHERE a.issue_id = %s ORDER BY a.created_at DESC
            """, (issue['id'],))

            for a in activities:
                st.markdown(f" **{a['name']}** — {a['action']} *({str(a['created_at'])[:16]})*")