import streamlit as st
from app.db import fetch_all, execute_query

def show():
    st.title(" Raise a New Issue")
    st.markdown("---")

    users = fetch_all("SELECT id, name FROM users")
    user_names = [u['name'] for u in users]
    user_map = {u['name']: u['id'] for u in users}

    error_types = [
        "TypeError",
        "ValueError", 
        "KeyError",
        "IndexError",
        "AttributeError",
        "ImportError",
        "SyntaxError",
        "NameError",
        "RuntimeError",
        "Other"
    ]

    with st.form("raise_issue_form"):
        
        st.subheader("Issue Details")
        
        title = st.text_input(
            "Issue Title *",
            placeholder="e.g. TypeError on line 42 in user_service.py"
        )

        description = st.text_area(
            "Description",
            placeholder="Describe the problem in detail...",
            height=100
        )

        st.subheader("Error Info")

        col1, col2 = st.columns(2)
        with col1:
            priority = st.selectbox(
                "Priority",
                ["low", "medium", "high"]
            )
        with col2:
            error_type = st.selectbox(
                "Error Type",
                error_types
            )

        error_message = st.text_area(
            "Error Message",
            placeholder="Paste the full error traceback here...",
            height=100
        )

        code_snippet = st.text_area(
            "Code Snippet",
            placeholder="Paste the relevant code here...",
            height=150
        )

        st.subheader("Assignment")

        col3, col4 = st.columns(2)
        with col3:
            raised_by_name = st.selectbox(
                "Raised By",
                user_names
            )
        with col4:
            assign_options = ["Unassigned"] + user_names
            assigned_to_name = st.selectbox(
                "Assign To",
                assign_options
            )

        st.markdown("---")
        submitted = st.form_submit_button("Submit Issue")

    if submitted:
        if not title.strip():
            st.error("Issue title is required!")
            return

        raised_by_id = user_map[raised_by_name]
        assigned_to_id = user_map.get(assigned_to_name) if assigned_to_name != "Unassigned" else None

        execute_query("""
            INSERT INTO issues 
            (title, description, error_message, code_snippet, 
             priority, error_type, raised_by, assigned_to)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            title,
            description,
            error_message,
            code_snippet,
            priority,
            error_type,
            raised_by_id,
            assigned_to_id
        ))

        st.success(f"✓ Issue '{title}' raised successfully!")
       