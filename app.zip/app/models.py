from sqlalchemy import Column, Integer, String, Text, Enum, TIMESTAMP, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base
import datetime

class User(Base):
    __tablename__ = "users"

    id         = Column(Integer, primary_key=True)
    name       = Column(String(100), nullable=False)
    email      = Column(String(150), unique=True, nullable=False)
    password   = Column(String(255), nullable=True)
    role       = Column(Enum('developer', 'admin'), default='developer')
    created_at = Column(TIMESTAMP, default=datetime.datetime.utcnow)

class Issue(Base):
    __tablename__ = "issues"

    id            = Column(Integer, primary_key=True)
    title         = Column(String(200), nullable=False)
    description   = Column(Text)
    error_message = Column(Text)
    code_snippet  = Column(Text)
    priority      = Column(Enum('low', 'medium', 'high'), default='medium')
    error_type    = Column(String(100))
    status        = Column(Enum('open', 'in-progress', 'resolved'), default='open')
    raised_by     = Column(Integer, ForeignKey('users.id'))
    assigned_to   = Column(Integer, ForeignKey('users.id'))
    created_at    = Column(TIMESTAMP, default=datetime.datetime.utcnow)
    updated_at    = Column(TIMESTAMP, default=datetime.datetime.utcnow)

class Comment(Base):
    __tablename__ = "comments"

    id         = Column(Integer, primary_key=True)
    issue_id   = Column(Integer, ForeignKey('issues.id'))
    user_id    = Column(Integer, ForeignKey('users.id'))
    comment    = Column(Text, nullable=False)
    likes      = Column(Integer, default=0)
    dislikes   = Column(Integer, default=0)
    created_at = Column(TIMESTAMP, default=datetime.datetime.utcnow)

class ActivityLog(Base):
    __tablename__ = "activity_log"

    id         = Column(Integer, primary_key=True)
    issue_id   = Column(Integer, ForeignKey('issues.id'))
    user_id    = Column(Integer, ForeignKey('users.id'))
    action     = Column(String(255), nullable=False)
    created_at = Column(TIMESTAMP, default=datetime.datetime.utcnow)

class CommentReaction(Base):
    __tablename__ = "comment_reactions"

    id         = Column(Integer, primary_key=True)
    comment_id = Column(Integer, ForeignKey('comments.id'))
    user_id    = Column(Integer, ForeignKey('users.id'))
    reaction   = Column(Enum('like', 'dislike'), nullable=False)
    created_at = Column(TIMESTAMP, default=datetime.datetime.utcnow)